﻿using Microsoft.AspNetCore.Mvc;

namespace PortofolioHW.Controllers
{
    public class ActivitiesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
