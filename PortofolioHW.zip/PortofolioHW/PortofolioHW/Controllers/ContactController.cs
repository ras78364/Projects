﻿using Microsoft.AspNetCore.Mvc;

namespace PortofolioHW.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
