﻿using Microsoft.AspNetCore.Mvc;

namespace PortofolioHW.Controllers
{
    public class FavoritesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
