﻿using Microsoft.AspNetCore.Mvc;

namespace PortofolioHW.Controllers
{
    public class AssignmentsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
