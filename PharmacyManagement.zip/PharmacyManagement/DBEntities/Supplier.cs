﻿using System;
using System.Collections.Generic;

namespace PharmacyManagement.DBEntities;

public partial class Supplier
{
    public int Supplierid { get; set; }

    public string SupplierName { get; set; } = null!;

    public string Mobile { get; set; } = null!;

    public virtual ICollection<Medicine> Medicines { get; set; } = new List<Medicine>();
}
