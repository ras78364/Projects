﻿using System;
using System.Collections.Generic;

namespace PharmacyManagement.DBEntities;

public partial class Medicine
{
    public int MedicineId { get; set; }

    public string Name { get; set; } = null!;

    public int CategoryId { get; set; }

    public int SupplierId { get; set; }

    public DateOnly ExpiryDate { get; set; }

    public decimal CostPrice { get; set; }

    public decimal SellingPrice { get; set; }

    public decimal Tax { get; set; }

    public int Qty { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual ICollection<InvoiceDetail> InvoiceDetails { get; set; } = new List<InvoiceDetail>();

    public virtual Supplier Supplier { get; set; } = null!;
}
