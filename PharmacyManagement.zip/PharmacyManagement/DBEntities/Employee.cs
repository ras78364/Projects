﻿using System;
using System.Collections.Generic;

namespace PharmacyManagement.DBEntities;

public partial class Employee
{
    public int EmployeeId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public bool Gender { get; set; }

    public decimal Salary { get; set; }

    public DateOnly JoinDate { get; set; }

    public string Password { get; set; } = null!;

    public string Email { get; set; } = null!;

    public int EmployeeCategoryId { get; set; }

    public virtual EmployeeCategory EmployeeCategory { get; set; } = null!;
}
