﻿using System;
using System.Collections.Generic;

namespace PharmacyManagement.DBEntities;

public partial class EmployeeCategory
{
    public int EmployeeCategoryId { get; set; }

    public string CategoryName { get; set; } = null!;

    public virtual ICollection<Employee> Employees { get; set; } = new List<Employee>();
}
