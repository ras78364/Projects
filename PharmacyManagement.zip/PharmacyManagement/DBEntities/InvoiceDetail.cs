﻿using System;
using System.Collections.Generic;

namespace PharmacyManagement.DBEntities;

public partial class InvoiceDetail
{
    public int InvoiceDetailId { get; set; }

    public int InvoiceMasterId { get; set; }

    public int MedicineId { get; set; }

    public int Qyt { get; set; }

    public decimal CostPrice { get; set; }

    public decimal Tax { get; set; }

    public decimal SellingPrice { get; set; }

    public virtual InvoiceMaster InvoiceMaster { get; set; } = null!;

    public virtual Medicine Medicine { get; set; } = null!;
}
