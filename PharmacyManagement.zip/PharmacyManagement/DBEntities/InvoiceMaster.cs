﻿using System;
using System.Collections.Generic;

namespace PharmacyManagement.DBEntities;

public partial class InvoiceMaster
{
    public int InvoiceMasterId { get; set; }

    public string? InvoiceNumber { get; set; }

    public DateTime? TransactionDate { get; set; }

    public decimal? TotalSellingAmount { get; set; }

    public virtual ICollection<InvoiceDetail> InvoiceDetails { get; set; } = new List<InvoiceDetail>();
}
