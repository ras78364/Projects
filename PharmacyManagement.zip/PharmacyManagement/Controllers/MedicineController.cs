﻿using Microsoft.AspNetCore.Mvc;

namespace PharmacyManagement.Controllers
{
    public class MedicineController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
