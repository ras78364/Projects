﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace PharmacyManagement.Controllers
{
    public class EmployeeController : Controller
    {
        DBEntities.HopePharmacyManagementContext context = new DBEntities.HopePharmacyManagementContext();
        public IActionResult Add()
        {
            ViewBag.EmpCategories = context.EmployeeCategories.ToList();

            return View();
        }
        public IActionResult AddNewEmployee(Models.EmployeeModel employeeModel)
        {
            DBEntities.Employee obj = new DBEntities.Employee();


            obj.FirstName = employeeModel.FirstName;
            obj.LastName = employeeModel.LastName;
            obj.Gender = employeeModel.Gender;
            obj.Salary = employeeModel.Salary;
            obj.JoinDate = employeeModel.JoinDate;
            obj.Password = employeeModel.Password;
            obj.Email = employeeModel.Email;
            obj.EmployeeCategoryId = employeeModel.EmployeeGategoryId;
            context.Employees.Add(obj);
            context.SaveChanges();
            return RedirectToAction("GettAll");
        }
        public IActionResult GettAll()
        {
            List<Models.EmployeeModel> lst = new List<Models.EmployeeModel>();
            lst = (from obj in context.Employees.Include(x => x.EmployeeCategory)
                   select new Models.EmployeeModel
                   {
                       EmployeeId = obj.EmployeeId,
                       FirstName = obj.FirstName,
                       LastName = obj.LastName,
                       GenderDisplayName = obj.Gender == true ? "Male" : "Female",
                       CategoryName = obj.EmployeeCategory != null ? obj.EmployeeCategory.CategoryName : "",
                       Salary= obj.Salary,
                          JoinDate= obj.JoinDate,

                   }).ToList();
            return View(lst);
        }
    }
}