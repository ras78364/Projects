﻿using System.ComponentModel.DataAnnotations;

namespace PharmacyManagement.Models
{
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public string FirstName { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public string LastName { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public bool Gender { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public DateOnly JoinDate { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public decimal Salary { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public string Email { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public string Password { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "This field is required")]
        public int EmployeeGategoryId { get; set; }
     public string GenderDisplayName { get; set; }
        public string CategoryName { get; set; }

    }
}
