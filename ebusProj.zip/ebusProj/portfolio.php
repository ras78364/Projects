<?php
include_once('Config.php');


$string = '<div class="row">';  

$result = query("select * from portfolio");

while ($row = mysqli_fetch_array($result)) {
    $string .= <<<DELIMETER
    <div class="col-md-4"> 
        <a href="components.php?portID={$row['Port_id']}" class="portfolio-card">
            <img src="assets/imgs/folio-1.jpg" class="portfolio-card-img"
                alt="Download free bootstrap 4 landing page, free bootstrap 4 templates, Download free bootstrap 4.1 landing page, free bootstrap 4.1.1 templates, Meyawo Landing page">
            <span class="portfolio-card-overlay">
                <span class="portfolio-card-caption">
                    <h4>{$row['Port_name']}</h4>
                    <p class="font-weight-normal">{$row['description']}</p>
                </span>
            </span>
        </a>
    </div>
    DELIMETER;
}

$string .= '</div>';
echo $string;
?>
