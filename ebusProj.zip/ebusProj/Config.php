<?php
session_start();

	$conn = mysqli_connect('localhost','root','','eBus') or die("Connection to DB failed");

function query($str){
	global $conn;
	$q = $str;
	return mysqli_query($conn, $q);
}

function getSubByID($id){
	global $conn;
	return query("SELECT * FROM subscription WHERE sub_id = $id");
}

function GetItemsByCat_Id($id){
	global $conn;
	return query("SELECT * FROM subscription WHERE Ser_id = $id AND Quantity >0");
}

function getItemInfo($i){
	global $conn;
	$q="select * from subscription where sub_id=$i ";
	$result=query($q);
	if(mysqli_num_rows($result)>0){
		$row=mysqli_fetch_assoc($result);
	    extract($row);	
	}
	
}

function getSub(){
	global $conn;
	return query("SELECT * FROM subscription where Quantity >0");
}
function login(){
	if(isset($_POST['Login'])){
		$user = $_POST['username'];
		$pass = $_POST['password'];
		
		$result = query("select * from users where username='{$user}' and password='{$pass}'");
		if(mysqli_num_rows($result) == 0){
			$_SESSION['error'] = "Username or password incorrect!!";
		}
		else{
			$row=mysqli_fetch_array($result);
			$_SESSION['username'] = $user;
			$_SESSION['email']=$row[4];
			header("Location:indexx.php");
		}
	}
}



?>
