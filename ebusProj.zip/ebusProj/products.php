<?php
include('Config.php');


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin - Products</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <?php
  
  include('adminHeader.php');
  
  ?>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body, html {
      height: 100%;
    }

    .wrapper {
      display: flex;
      height: 100%;
    }

    .content {
      flex-grow: 1;
      padding: 20px;
      background-color: #f4f4f4;
    }

    .header {
      background-color: #ffffff;
      padding: 15px 20px;
      margin-bottom: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .header h1 {
      font-size: 24px;
      color: #333;
    }

    .add-product {
      background-color: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .add-product h2 {
      margin-bottom: 15px;
    }

    .add-product form input[type="text"],
    .add-product form input[type="number"] {
      width: 30%;
      padding: 10px;
      margin: 5px 10px 10px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .add-product form button {
      padding: 10px 20px;
      background-color: #27ae60;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .add-product form button:hover {
      background-color: #219150;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background-color: #fff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    table th, table td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }

    table th {
      background-color: #ecf0f1;
    }

    .action-buttons button {
      margin-right: 5px;
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      color: white;
    }

    .edit-btn {
      background-color: #2980b9;
    }

    .delete-btn {
      background-color: #c0392b;
    }

    .edit-btn:hover {
      background-color: #1f6391;
    }

    .delete-btn:hover {
      background-color: #a7281d;
    }
  </style>
</head>
<body>

<div class="wrapper">
  <?php include('sideBar.php'); ?>

  <div class="content">
    <div class="header">
      <h1>Manage Products</h1>
    </div>

    <div class="add-product">
      <h2>Add New Product</h2>
      <form method="POST" action="products.php">
    <input type="text" name="sub_name" placeholder="Product Name" required />
    <input type="text" name="ser_id" placeholder="Category ID" required />
    <input type="number" name="price" placeholder="Price ($)" required />
    
    <button type="submit" name="add_product">Add Product</button>
</form>

    </div>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Category</th>
          <th>Price ($)</th>
          
          
        </tr>
      </thead>
     <tbody>
<?php
$result = query("SELECT sub_id, sub_name, ser_id, price FROM subscription");
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>{$row['sub_id']}</td>
            <td>{$row['sub_name']}</td>
            <td>{$row['ser_id']}</td>
            <td>\${$row['price']}</td>
            <td class='action-buttons'>
                <a href='products.php?delete_id={$row['sub_id']}' class='delete-btn'>Delete</a>
            </td>
          </tr>";
}
?>
</tbody>

    </table>
  </div>
</div>

</body>
</html>
