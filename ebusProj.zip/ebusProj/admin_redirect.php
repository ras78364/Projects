<?php
session_start();

if (isset($_SESSION['username'])) {
    header("Location: indexx.php"); 
} else {
    header("Location: login.php"); 
}
exit();
