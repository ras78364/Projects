<?php
include_once('Config.php');
include('subCart.php');	
include('navbar.php');

?>
<?php
if(isset($_GET['minus'])){
$_SESSION[$_GET['iid']]--;	
	if($_SESSION[$_GET['iid']]==0)
		unset($_SESSION[$_GET['iid']]);
}elseif(isset($_GET['plus'])){
	$_SESSION[$_GET['iid']]++;
	
}elseif(isset($_GET['delete'])){
	unset($_SESSION[$_GET['iid']]);
	
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Checkout page">
    <meta name="author" content="Devcrud">
    <title>Checkout | Meyawo Theme</title>

    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">
    <!-- Bootstrap + Meyawo main styles -->
    <link rel="stylesheet" href="assets/css/meyawo.css">
	<style>
	
.navbar .nav-link {
    font-size: 1rem !important;  /* or 16px */
}
.navbar-brand {
    font-size: 1.25rem !important; /* Adjust if needed */
}

	</style>
</head>

<body>

    <!-- Navbar -->
    

    <!-- Header -->
    <header id="home" class="header">
        <div class="overlay"></div>
        <div class="header-content container">
            <h1 class="header-title">
                <span class="up">WELCOME TO</span>
                <span class="down">Checkout Page</span>
            </h1>
            <p class="header-subtitle">Complete your order</p>
        </div>
    </header>

    <!-- Checkout Form -->
    <section class="section">
	<?php
	if(isset($_GET['print']))
		
	
	?>
        <section class="section">
    <div class="container">
        <h2 class="mb-5 text-center">Checkout</h2>
		<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post"> 
<input type="hidden" name="cmd" value="_cart"> 
<input type="hidden" name="business" value="ras0226653@ju.edu.jo">
<input type="hidden" name="upload" value="1">
<input type="hidden" name="currency_code" value="USD">
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                
                <tbody>
                    <?php checkoutTable(); ?>
                    
                    <tr>
                        <td colspan="4" class="text-right"><strong>Total</strong></td>
                        <td><strong><?php echo $itemSum ?></strong></td>
                    </tr>
                </tbody>
            </table>
			<input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" 
			alt="PayPal - The safer, easier way to pay online"> 
        </div>
       
    </div>
</section>

               
                    
                
            

    
    </section>

    

    <!-- JavaScript -->
    

</body>

</html>

<?php
include('footer.php');
?>	