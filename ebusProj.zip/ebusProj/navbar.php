<nav id="main-navbar" class="custom-navbar navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a class="navbar-brand logo" href="#">Meyawo</a>
        <button class="navbar-toggler" type="button" id="nav-toggle" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav-menu">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#about">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#portfolio">Portfolio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#testmonial">Testimonial</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#blog">Blog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contact">Contact</a>
                </li>
				
				 <li class="nav-item">
				 
                    <a class="nav-link" href="login.php">Admin</a>
                </li>
				 <li class="nav-item">
				 
                    <a class="nav-link" href="checkout.php">Checkout</a>
                </li>
                <li class="nav-item">
                    <a href="components.php" class="btn btn-outline-light ml-md-3">Components</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
