<!DOCTYPE html>
<html lang="en">
<head>
  <?php 
  include_once('Config.php');
  include('adminHeader.php');
 
if(!isset($_SESSION['username'])){
		
		header("Location:login.php");
		
	}
	/*if($_SERVER['REQUEST_URI']=="/ebusProj/index.php"|| $_SERVER['REQUEST_URI']!= /ebusProj/)
		header("Location:login.php");
	*/
  ?>
</head>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php include('sideBar.php'); ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <h2 class="text-center mb-4">Order List</h2>

          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="ordersTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Transaction </th>
                      <th>Currency</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Paypal ID</th>
                     
					  <th>Date</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php
				  
				  $q = "SELECT ID, amount, status, transaction, currency, DateTime from payments";

				  $result=query($q);
				  $tableRows="";
				  while ($row = mysqli_fetch_array($result)) {
    $tableRows .= <<<DELIMETER
    <tr>
        <td>{$row['ID']}</td>
        <td>{$row['currency']}</td>
        <td>{$row['amount']}</td>
        <td>{$row['status']}</td>
        <td>{$row['transaction']}</td>
        <td>{$row['DateTime']}</td>
    </tr>
    DELIMETER;
}

echo $tableRows;
				  
				  ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
       

      </div>
     
    </div>
   

  </div>
 

 
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="admin/sb-admin-2.min.js"></script>

</body>
</html>
