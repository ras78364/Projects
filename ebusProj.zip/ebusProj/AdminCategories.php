<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin - Categories</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <?php
  include('adminHeader.php');
  
  
  ?>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body, html {
      height: 100%;
    }

    .wrapper {
      display: flex;
      height: 100%;
    }

    .content {
      flex-grow: 1;
      padding: 20px;
      background-color: #f4f4f4;
    }

    .header {
      background-color: #ffffff;
      padding: 15px 20px;
      margin-bottom: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .header h1 {
      font-size: 24px;
      color: #333;
    }

    .add-category {
      background-color: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .add-category h2 {
      margin-bottom: 10px;
    }

    .add-category input[type="text"] {
      width: 70%;
      padding: 10px;
      margin-right: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .add-category button {
      padding: 10px 20px;
      background-color: #27ae60;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .add-category button:hover {
      background-color: #219150;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background-color: #fff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    table th, table td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }

    table th {
      background-color: #ecf0f1;
    }

    .action-buttons button {
      margin-right: 5px;
      padding: 6px 12px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      color: white;
    }

    .edit-btn {
      background-color: #2980b9;
    }

    .delete-btn {
      background-color: #c0392b;
    }

    .edit-btn:hover {
      background-color: #1f6391;
    }

    .delete-btn:hover {
      background-color: #a7281d;
    }
  </style>
</head>
<body>

<div class="wrapper">
  <!-- Sidebar (no design changes) -->
  <?php include('sideBar.php'); ?>

  <!-- Main content area -->
  <div class="content">
    <div class="header">
      <h1>Manage Categories</h1>
    </div>

    <div class="add-category">
      <h2>Add New Category</h2>
      <input type="text" placeholder="Enter category name" />
      <button>Add</button>
    </div>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Category Name</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Electronics</td>
          <td class="action-buttons">
            <button class="edit-btn">Edit</button>
            <button class="delete-btn">Delete</button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>Books</td>
          <td class="action-buttons">
            <button class="edit-btn">Edit</button>
            <button class="delete-btn">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>

