<?php
include('Config.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Panel - Users</title>

  <?php include('adminHeader.php'); ?>
<?php
if (isset($_POST['add_user'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];
  $email = $_POST['email'];
  $Role=$_POST['Role'];
  
  query("INSERT INTO users (username, password, email,Role) VALUES ('$username', '$password', '$email','$Role')");
  header("Location: users.php");
  exit;
}
if (isset($_POST['delete'])) {
  $id = intval($_POST['delete_id']);
  query("DELETE FROM users WHERE userid = $id");
  header("Location: users.php"); 
  exit;
}
?>

  <style>
    /* Your custom styles */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f0f2f5;
    }
    .container {
      width: 90%;
      max-width: 1100px;
      margin: 40px auto;
      background: #fff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
    }
    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    th, td {
      padding: 12px 16px;
      text-align: center;
      border-bottom: 1px solid #e0e0e0;
    }
    th {
      background-color: #f7f9fc;
      font-weight: 600;
      color: #444;
    }
    tr:hover {
      background-color: #f1f5f9;
    }
    .status-active {
      color: green;
      font-weight: bold;
    }
    .status-disabled {
      color: red;
      font-weight: bold;
    }
    .actions button {
      padding: 5px 10px;
      margin: 0 2px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
    }
    .edit-btn {
      background-color: #3498db;
      color: white;
    }
    .delete-btn {
      background-color: #e74c3c;
      color: white;
    }
	form {
  margin-bottom: 20px;
}
form input {
  padding: 8px;
  margin: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
form button {
  padding: 8px 12px;
  background-color: #2ecc71;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

  </style>
</head>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php include('sideBar.php'); ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Page Content -->
        <div class="container">
          <h2>User Management</h2>
		  <h3>Add New User</h3>
<form method="POST" action="">
  <input type="text" name="username" placeholder="Username" required>
  <input type="text" name="password" placeholder="Password" required>
  <input type="text" name="email" placeholder="Email" required>
  <input type="text" name="Role" placeholder="Role" required>
  <button type="submit" name="add_user">Add User</button>
</form>
<hr>

          <table>
            <thead>
              <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
              </tr>
            </thead>
           <tbody>
<?php
$result = query("SELECT * FROM users");
while ($row = mysqli_fetch_assoc($result)) {
  echo "<tr>";
  echo "<td>{$row['userid']}</td>";
  echo "<td>{$row['username']}</td>";
  echo "<td>{$row['email']}</td>";
  echo "<td>{$row['Role']}</td>";
  
  echo "<td class='actions'>
          <form method='POST' style='display:inline;'>
            <input type='hidden' name='delete_id' value='{$row['userid']}'>
            <button type='submit' name='delete' class='delete-btn'>Delete</button>
          </form>
        </td>";
  echo "</tr>";
}
?>
</tbody>

          </table>
        </div>

      </div>
     

    </div>
  

  </div>


  <!-- Scripts (required by SB Admin 2) -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="admin/sb-admin-2.min.js"></script>

</body>
</html>
