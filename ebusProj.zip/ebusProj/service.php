<?php
include_once('Config.php');

//connect();

$string = '<div class="row">';  

$res = query("SELECT * FROM services");

while ($row = mysqli_fetch_array($res)) {  
    $string .= <<<DELIMETER
    <div class="col-md-6 col-lg-3">  
        <div class="service-card">
            <div class="body">
                <img src="assets/imgs/pencil-case.svg"
                    alt="Service Icon"
                    class="icon">
                <a href="Category.php?service_id={$row['Service_id']}"><h6 class="title">{$row['Service_name']}</h6></a>
                <p class="subtitle">{$row['description']}</p>
                <p class="subtitle">{$row['Long_description']}</p>
            </div>
        </div>
    </div>
    DELIMETER;
}

$string .= '</div>';  
echo $string;  
?>
