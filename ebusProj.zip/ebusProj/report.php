<?php
include('Config.php');

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$result = query("SELECT ID, amount, status, transaction, currency, DateTime FROM payments ORDER BY DateTime DESC");

// Calculate total earnings
$total_result = query("SELECT SUM(amount) as total FROM payments WHERE status = 'Completed'");
$total_row = mysqli_fetch_assoc($total_result);
$total_earnings = $total_row['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transaction Report</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    @media print {
      .no-print {
        display: none;
      }
    }
    body {
      padding: 30px;
      background-color: #f8f9fa;
    }
    h2, h4 {
      text-align: center;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      background: #fff;
    }
    th, td {
      text-align: center;
    }
    .total-box {
      text-align: right;
      font-size: 1.2rem;
      margin-top: 20px;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="d-flex justify-content-between align-items-center no-print mb-4">
      <h2>Transaction Summary Report</h2>
      <button class="btn btn-primary" onclick="window.print()">🖨️ Print</button>
    </div>

    <table class="table table-bordered">
      <thead class="thead-dark">
        <tr>
          <th>Transaction ID</th>
          <th>Currency</th>
          <th>Amount</th>
          <th>Status</th>
          <th>PayPal ID</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
          <tr>
            <td><?= $row['ID'] ?></td>
            <td><?= $row['currency'] ?></td>
            <td>$<?= number_format($row['amount'], 2) ?></td>
            <td><?= $row['status'] ?></td>
            <td><?= $row['transaction'] ?></td>
            <td><?= $row['DateTime'] ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

    <div class="total-box">
      Total Earnings (Completed Only): $<?= number_format($total_earnings, 2) ?>
    </div>

    <div class="text-right mt-4 no-print">
      <a href="indexx.php" class="btn btn-secondary">← Back to Dashboard</a>
    </div>
  </div>

</body>
</html>
