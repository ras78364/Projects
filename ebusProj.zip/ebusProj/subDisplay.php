<?php
include('Config.php');
include('header.php');
include('navbar.php');



if (!isset($_GET['subID'])) {
    die("subID is not provided.");
}

$res = getSubByID($_GET['subID']);
$row = mysqli_fetch_array($res);
if (!$row) {
    die("Error fetching the subscription details.");
}

$item = <<<DELIMETER
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-4 col-md-6">  
            <div class="pricing-card" style="padding: 15px; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);">
                <div class="pricing-card-header text-center">
                 
                </div>
                <div class="pricing-card-body text-center" style="font-size: 1rem;">  
                    <h5 class="pricing-card-title">{$row['sub_name']}</h5>
                    <div class="pricing-card-list">
                        <p>{$row['description']}</p>
						 <p>{$row['Long_dscription']}</p>
                    </div>
                </div>
                <div class="pricing-card-footer text-center">
                    <span style="font-size: 1.2rem; font-weight: bold;">$</span>
                    <span style="font-size: 1.2rem;">{$row['price']}</span>
                    <p></p>
                </div>
                <div class="text-center">
                    <a href="subcart.php?itemid=$row[sub_id]" class="btn btn-primary mt-3 pricing-card-btn" style="padding: 8px 20px;">Add to cart</a>
                </div>
            </div>
        </div>
    </div>
</div>
DELIMETER;


echo $item;

include('footer.php');


?>
