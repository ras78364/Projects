<?php
include_once('config.php');
include('header.php');
include('navbar.php');


$string = '<div class="row">'; 

if (isset($_GET['service_id'])) {
   $res=GetItemsByCat_Id($_GET['service_id']);
}
else{
$res=getSub();
}
while ($row = mysqli_fetch_array($res)) {
    $string .= <<<DELIMETER
        <div class="col-lg-4 col-md-6">  
            <div class="pricing-card" style="padding: 15px; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);">
                <div class="pricing-card-header">
                    
                </div>
                <div class="pricing-card-body" style="font-size: 1rem;">  
                   <a href="subDisplay.php?subID={$row['sub_id']}" <h5 class="pricing-card-title">{$row['sub_name']}</h5></a>
                    <div class="pricing-card-list">
                        <p>{$row['description']}</p>
                    </div>
                </div>
                <div class="pricing-card-footer">
                    <span style="font-size: 1.2rem; font-weight: bold;">$</span>
                    <span style="font-size: 1.2rem;">{$row['price']}</span>
                </div>
                
            </div>
        </div>  <!-- col-lg-4, col-md-6 -->
DELIMETER;
}

$string .= '</div>';  
echo $string;


include('footer.php');



?>