<?php
include_once('Config.php');
?>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<?php

$itemCount=0;
$itemSum=0;
if(isset($_GET['itemid'])){
	addtoCart($_GET['itemid']);
	
	
	
}
function addtoCart($id){
	if(isset($_SESSION['sub'. $id])){
		$_SESSION['sub'. $id]++;		
}
	else{
		$_SESSION['sub'. $id]=1;
		
	}
	header('Location:index.php');
}
function printCart(){
	if(isset($_SESSION)){
		
		
		
	}
	
}
function checkoutTable(){
    global $itemCount, $itemSum;
    if (!isset($_SESSION)) return;

    $itemcounter = 0;
    $itemSum = 0; // Make sure this is reset before summing

    // Table headers (only once)
    echo <<<HEADERS
<thead class="thead-dark">
    <tr>
        <th>Item ID</th>
        <th>Name</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>sub_Total</th>
    </tr>
</thead>
<tbody>
HEADERS;

    foreach($_SESSION as $key => $value){
        if(substr($key, 0, 3) == 'sub'){
            $itemcounter++;
            $itemid = substr($key, 3);
            $res = query("SELECT * FROM subscription WHERE sub_id = $itemid");

            if (!$res || mysqli_num_rows($res) == 0) continue;

            $sub = mysqli_fetch_array($res);
            $total = ($sub['price'] * $value);

            $itemCount = $value;
            $itemSum += $total;

            echo <<<ROW
    <tr>
        <td>{$sub['sub_id']}</td>
        <td>{$sub['sub_name']}</td>
        <td>$value</td>
        <td>&#36;{$sub['price']}</td>
        <td>&#36;$total</td>
		<td>
		<a href="checkout.php?minus=1&iid={$key}">
		<button type="button" class="btn btn-warning glyphicon glyphicon-minus"></button>
		</a>
		<a href="checkout.php?plus=1&iid={$key}">
		<button type="button" class="btn btn-success glyphicon glyphicon-plus"></button>
		</a>
		<a href="checkout.php?delete=1&itemid={$key}">
		<button type="button" class="btn btn-danger glyphicon glyphicon-remove"></button>
		</a>
		</td>
    </tr>
    <input type="hidden" name="item_name_{$itemcounter}" value="{$sub['sub_name']}"> 
    <input type="hidden" name="item_number_{$itemcounter}" value="{$itemcounter}">
    <input type="hidden" name="amount_{$itemcounter}" value="{$sub['price']}"> 
    <input type="hidden" name="quantity_{$itemcounter}" value="$value"> 
ROW;
        }
    }

    echo "</tbody>"; // Close the table body
}


function checkoutTable2(){
    global $itemSum;
     
    foreach($_SESSION as $key => $value){
		
        if(substr($key, 0, 3) == 'sub'){
            $itemid = substr($key, 3);
            $res = query("SELECT * FROM subscription WHERE sub_id = $itemid");
            $sub = mysqli_fetch_array($res);
            $total = ($sub['price'] * $value);

            $itemSum += $total;

            $row = <<<DELIMETER
<thead class="thead-dark">
    <tr>
        <th>{$sub['sub_id']}</th>
        <th>{$sub['sub_name']}</th>
        <th>$value</th>
        <th>&#36;{$sub['price']}</th>
        <th>&#36;$total</th>
    </tr>
</thead>

DELIMETER;

            echo $row;
        }
    }
}
?>