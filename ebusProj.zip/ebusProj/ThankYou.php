<?php
include_once('Config.php');
include('subCart.php');	
include('navbar.php');
function insertVariables($tx, $st, $cc, $amt,$fname,$lname,$payment_date) {
    global $conn;
  
    $q = "insert into payments(First_name, Last_name, amount, status, transaction, currency,DateTime) values ('$fname', '$lname', $amt, '$st', '$tx', '$cc',$payment_date)";
    $res=query($q);

    if (mysqli_affected_rows($conn)>0) {
        echo "<p style='color:green;'>Transaction saved successfully.</p>";
    } else {
        echo "<p style='color:red;'>Error: "."</p>";
    }

    
}
if (isset($_GET['st']) && $_GET['st'] == 'Completed') {

    $trans= $_GET['tx'];
    $amt = $_GET['amt'];
    $cc = $_GET['cc'];
    $st = $_GET['st'];
     $fname=$_GET['first_name'];
	   $lname=$_GET['last_name'];
    insertVariables($trans, $st, $cc, $amt,$fname, $lname);
}

if (isset($_GET['st']) && $_GET['st'] == 'Completed') {
    foreach ($_SESSION as $key => $value) {
        if (substr($key, 0, 3) == 'sub') {
            $Id = substr($key, 3);
            $quantityOld = $_SESSION['sub' . $Id];

            $q1 = "SELECT Quantity FROM subscription WHERE sub_id = $Id";
            $result1 = query($q1);
            if (!$result1 || mysqli_num_rows($result1) == 0) {
                echo "<p style='color:red;'>Error retrieving quantity for item ID $Id.</p>";
                continue;
            }

            $row = mysqli_fetch_array($result1);
            $stock = $row['Quantity'];
            $diff = $stock-$quantityOld;

            $q2 = "UPDATE subscription SET Quantity = $diff WHERE sub_id = $Id";
            $result2 = query($q2);

            if (!$result2) {
                echo "<p style='color:red;'>Failed to update stock for item ID $Id.</p>";
            }
        }
    }
	$purchaseQty = abs($_SESSION['sub' . $Id]);

$newQty = max(0, $stock - $purchaseQty); // Prevent negative quantities

$q2 = "UPDATE subscription SET Quantity = $newQty WHERE sub_id = $Id";
$result2 = query($q2);

if (!$result2) {
    echo "<p style='color:red;'>Failed to update stock for item ID $Id.</p>";
}


session_destroy();	
}

//
// &amt=199.00&tx=4HR942620T076394X&st=Completed&cc=USD&first_name=rashed&last_name=jardaneh






?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Checkout page">
    <meta name="author" content="Devcrud">
    <title>Thank you | Meyawo Theme</title>
  <style>
@media print {
    body * {
        visibility: hidden;
    }
    #printableArea, #printableArea * {
        visibility: visible;
    }
    #printableArea {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        padding: 20px;
        font-family: Arial, sans-serif;
    }
}
</style>



    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">
    <!-- Bootstrap + Meyawo main styles -->
    <link rel="stylesheet" href="assets/css/meyawo.css">
	
</head>

<body>

    

    <!-- Header -->
    <header id="home" class="header">
        <div class="overlay"></div>
        <div class="header-content container">
            <h1 class="header-title">
                
                <span class="down">Thank You!!  </span>
				<span>Your payment was succsessful</span>
				<br>
            </h1>
           
        </div>
    </header>

    <!-- Checkout Form -->
    <section class="section">
	<?php
	if(isset($_GET['print']))
		
	
	?>
        <section class="section">
    <div class="container">
		<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post"> 
    <input type="hidden" name="cmd" value="_cart"> 
    <input type="hidden" name="business" value="ras0226653@ju.edu.jo"> 
    <input type="hidden" name="upload" value="1"> 
    <input type="hidden" name="currency_code" value="USD">
    
    <!-- Redirect after payment -->
    <input type="hidden" name="return" value="http://localhost/ebusProj/thankyou.php">
    <input type="hidden" name="cancel_return" value="http://localhost/ebusProj/checkout.php">


    <a class="btn" href="index.php?paid=1"> Return to homepage </a>
</form>

            <table class="table table-bordered text-center">
                
                <tbody>
                    <?php checkoutTable2(); ?>
                    
                    <tr>
                        <td colspan="4" class="text-right"><strong>Total</strong></td>
                        <td><strong><?php echo $itemSum ?></strong></td>
                    </tr>
                </tbody>
            </table>
			<div id="printableArea" class="container mt-4">
    <h2>Payment Receipt</h2>
    <p><strong>First Name:</strong> <?php echo $fname; ?></p>
    <p><strong>Last Name:</strong> <?php echo $lname; ?></p>
    <p><strong>Amount:</strong> <?php echo $amt . ' ' . $cc; ?></p>
    <p><strong>Status:</strong> <?php echo $st; ?></p>
    <p><strong>Transaction ID:</strong> <?php echo $trans; ?></p>
</div>

<!-- Print Button -->
<button onclick="printReceipt()" class="btn btn-primary mt-3">🖨️ Print Receipt</button>

        </div>
       
    </div>
</section>

               
                    
                
            

    
    </section>

    <script>
function printReceipt() {
    window.print();
}
</script>


    <!-- JavaScript -->
    

</body>

</html>

<?php
include('footer.php');
?>